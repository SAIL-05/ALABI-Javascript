
console.log('Welcome to SAIL')

console.log(document.getElementsByClassName('text'))
console.log(document.getElementsByClassName('text')[0].innerText)

document.getElementById('header').textContent = 'I have been changed by Javascript'

// [{},{},{},{}]
console.log(window.document.querySelectorAll('li')[2].innerText)

console.log(document.getElementById('header'))
console.log(document.getElementById('header'))

// console.log(document.querySelector('.header'))
// console.log(document.querySelector('#header'))
console.log(document.querySelector('p'))

console.log(document.querySelectorAll('p'))

let student = {
    name: 'Ronaldo',
    nationality: 'Portuguese',
    status: 'second greatest of all time',

    innerText: '',
    innectHTML: '',
    textContent: ''
}

// student.name

// textContent
// innerHTML
// innerText

// {
//     name: 'ife',
//     gender: 'male'
// }

// ['name']
// .name

// document.getElementById
// document.querySelector
// document.querySelectorAll

// let header =document.getElementById('header')

// header.style.color = "hotpink"

// header.style.backgroundColor = "orange"

// header.style.fontSize = "100px"

// const showAlert = ()=>{
//     let sum  = 2+2 
//     alert( `my sum is ${sum}`)
// }


// ill practice event listeners todaty

